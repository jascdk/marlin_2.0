Ender 3 Pro - SKR 1.4 Turbo - BTT TFT35 - working setup (16 Oct 2026)

Marlin-2.1.2.9/
  Configuration.h, Configuration_adv.h
    Official Marlin 2.1.2.9 example "Creality/Ender-3 Pro/BigTreeTech SKR 1.4 Turbo"
    plus only these changes:
      - Name "Jacobs Ender 3 Pro", BAUDRATE 115200, no boot screens
      - Hotend thermistor TEMP_SENSOR_0 5, E-steps 99
      - Hotend PID 28.5971 / 2.2902 / 89.2731 (M303 E0 S210 C8)
      - Bed PID 104.93 / 19.85 / 369.73
      - BLTouch on P0_10, offset { -64, -2, 0 }, BLTOUCH_HS_MODE true
      - M48 probe test + G26 first layer test enabled
      - MANUAL_Y_HOME_POS -9, physical endstops (SENSORLESS_HOMING off)
      - Marlin mode via EXP1/EXP2 (REPRAP_DISCOUNT_FULL_GRAPHIC_SMART_CONTROLLER)
      - RX_BUFFER_SIZE 1024, ADVANCED_OK off
      - BTT TFT / OctoPrint reporting options, babystep Z-offset
  firmware.bin
    Built from exactly these two files.

  Flash: copy firmware.bin alone to the SKR SD card (FAT32), power on, wait ~30 s
         (file becomes FIRMWARE.CUR). Then: M502, M500, G28, set Z-offset, M500.

  Compile yourself: put both files in Marlin-2.1.2.9/Marlin/, quit VS Code,
                    rm -rf .pio, ~/.platformio/penv/bin/platformio run -e LPC1769

BTT-screen/config.ini
  serial_port P1:6 (115200), advanced_ok 0, command_checksum 0, tx_delay 2,
  custom buttons 8-12. Copy to the screen's SD card root (run dot_clean on a Mac).

test-print/test-box-20mm.stl
  20x20x20 mm open-top box, 1.6 mm walls, 1.2 mm floor. Cura: Wall Line Count 4.

Still to do (one change at a time, test print after each):
  1. BLTouch cable test: M401, M119 (open), push pin, M119 (TRIGGERED), wiggle cable.
  2. Linear Advance K calibration.
  3. Input shaping, then speed/acceleration.
